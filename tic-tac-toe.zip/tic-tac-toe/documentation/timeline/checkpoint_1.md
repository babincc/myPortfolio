# Checkpoint 1

For this first chunk of the project, from all of the [user stories](../user%20stories.md) that were made in the beginning, "Learn how to play", "Start game", "Multiplayer", and "Keep score" were chosen as the first things to be added to the app.

The first few pages of the user interface that the player will see when they start the game were created; this was done in Android Studio. The three pages are the home/welcome screen, the instructions screen, and the game/playing-field screen.

Then, the java code connecting each of the activities and allowing the multiplayer game to function was implemented.

Note: There is very little error handling right now. Programming is being done under the assumption that only developers and professors will be using the app, and they will use correct inputs. Error handling will come in later iterations as it may change when new inputs become possible. Also, this checkpoint is only the multiplayer game mode. The computer has not yet been programmed to play against a user.
