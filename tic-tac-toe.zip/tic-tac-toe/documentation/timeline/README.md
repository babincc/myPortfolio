# Timeline

| Document | Description |
| --- | --- |
| [Checkpoint 1](checkpoint_1.md) | Everything that was completed during the first portion of the project. |
| [Checkpoint 2](checkpoint_2.md) | Everything done in the middle portion of the project. |
| [Checkpoint 3](checkpoint_3.md) | All of the final additions to the project. |
