# Documentation

| Document(s) | Description |
| --- | --- |
| [presentation movie](presentation%20movie.mov) | This short video shows how an interaction with the app might go. |
| [timeline](timeline) | This is a group of documents covering each step of the process while making this app. |
| [user stories](user%20stories.md) | This is a list of features that need to be included in the app (written in the format of [user stories (external link)](https://en.wikipedia.org/wiki/User_story)). |
