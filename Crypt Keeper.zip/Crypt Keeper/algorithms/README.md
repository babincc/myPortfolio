# Algorithms

Here are detailed breakdowns of how the encryption and decryption works for each version of the program. They are laid out below with the most recent version of the program at the top and the oldest at the bottom.

<br>

#### Version History
- [v3.1.0 - v3.3.0](v3.1.0%20-%20v3.3.0.md)
- [v3.0.0](v3.0.0.md)
- [v2.0.0](v2.0.0.md)
- [v1.0.0 - v1.0.2](v1.0.0%20-%20v1.0.2.md)
