# js

These are the javascript files for the website.

## Folder Layout

[**index**](index.js) - This is the file that is specific to this website.

[**jquery-3.5.1**](jquery-3.5.1.js) - This is the version of jQuery the website is using (3.5.1).

[**prefixfree.min**](prefixfree.min.js) - This is a javascript library that makes css work more nicely.
