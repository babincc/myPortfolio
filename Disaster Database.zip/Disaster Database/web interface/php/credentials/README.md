# php

This is where the database login information is stored. The website uses these to login to the database.

## Folder Layout

[**key**](key.php) - This is the login for the public. It has lots of restrictions.
[**skeleton_key**](skeleton_key.php) - This is the login for users with the PIN. It has less restrictions.
