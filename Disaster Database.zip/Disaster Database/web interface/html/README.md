# html

These files are the meat and potatoes of the website. They hold all of the information that the user sees.

## Folder Layout

[**about**](about.html) - This page talks about the database so the user can learn about it.

[**index**](index.html) - This is the home page for the website.
