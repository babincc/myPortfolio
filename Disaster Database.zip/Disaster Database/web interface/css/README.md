# css

These files control the formatting and layout of the website.

## Folder Layout

[**responsive**](responsive.css) - This is the secondary style sheet. It comes into play when the screen size becomes too small.

[**style**](style.css) - This is the main style sheet.
