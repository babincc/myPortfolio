# design diagrams

This folder is used to store the design diagrams for the database.

## Up-to-date Files

[**e-r diagram draft 3**](e-r%20diagram%20draft%203.jpg) is the most up-to-date e-r diagram

[**normalized relational schemas draft**](normalized%20relational%20schemas%20draft.md) is the most up-to-date set of *normalized* relational schemas based off of the most up-to-date e-r diagram

[**relational schemas draft 2**](relational%20schemas%20draft%202.md) is the most up-to-date set of relational schemas based off of the most up-to-date e-r diagram
