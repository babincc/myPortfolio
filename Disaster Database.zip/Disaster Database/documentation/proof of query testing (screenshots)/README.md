# proof of query testing (screenshots)

These are the screenshots for the proof of testing for each query. They are numbered to correspond to their query number in the [problem statement](../phase%202%20final%20problem%20statement.md).

It is recommended that you read [proof of query testing](../proof%20of%20query%20testing.md) rather than trying to just look at the screenshots.
