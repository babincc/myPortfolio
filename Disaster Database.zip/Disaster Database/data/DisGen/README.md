# DisGen
Current version: v3.2.1

<br>

DisGen (Disaster Generator) is a program designed to generate a user selected number of disaster data entries for a specific user selected disaster. These entries are meant to be used for my CMSC 508 semester project and are not real data.

To use this program, you will need to download the "src" folder and compile the "Gen_A_Disaster.java" file (/src/main/Gen_A_Disaster.java) in the command prompt/terminal. You will need to make sure that the most up to date location data file in the "src" folder. You will then need to run the "Gen_A_Disaster.class" file (/src/main/Gen_A_Disaster.class) and follow the instructions that it gives you. After it runs, it will have generated a .csv file in the "src" folder with all of your newly generated disaster data for the disaster of your choice.
