# database tables

This folder is used to store the examples of the database. They are they tables that are in the database.

## Up-to-date Files

[**tables**](tables) is the most up-to-date set of database tables.

## helpful programs

I created this program so that I could easily take the data and place it into tables for the project.

- [Tables R Us](Tables%20R%20Us) is a program used to generate the database tables for this project. Details are in the README file in the Tables R Us folder.
